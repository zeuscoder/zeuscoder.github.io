import { createApp } from './app.js';

createApp().mount('#app');
